* install nodejs
* from root of this rep run ./scripts/web-server.js
* open browser and go to http://localhost:8001/dash/app/index.html
